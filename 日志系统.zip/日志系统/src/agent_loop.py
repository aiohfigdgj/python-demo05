"""Agent 核心循环：OBSERVE → THINK → ACT → EVALUATE，逐步写 trace 日志。

循环结构：
    OBSERVE   ：读取当前状态（用户输入）
    THINK     ：决定下一步做什么（选什么工具/动作）
    ACT       ：执行动作，拿到结果
    EVALUATE  ：判断是否完成；未完成回到 OBSERVE，最多 max_steps 轮
"""
from __future__ import annotations

import logging

from .trace_logger import TraceLogger

log = logging.getLogger(__name__)


class AgentLoop:
    """Agent 基类：封装循环与 trace 日志。子类实现 think/act/evaluate。"""

    def __init__(self, name: str, max_steps: int = 5):
        self.name = name
        self.max_steps = max_steps
        self.trace: TraceLogger | None = None  # 每次 run() 时创建，保证一次执行一个 trace_id

    def run(self, user_input: str) -> tuple[str, str]:
        """执行 Agent Loop，返回 (trace_id, final_answer)。"""
        # 每次执行生成独立 trace（黑匣子按"一次执行"归档）
        self.trace = TraceLogger(self.name)
        self.trace.step("OBSERVE", input=user_input)

        result = None
        done = False
        step = 0
        for step in range(1, self.max_steps + 1):
            # THINK：决定动作
            action = self.think(user_input, result)
            self.trace.step("THINK", step=step, plan=action)

            # ACT：执行动作
            result = self.act(action)
            self.trace.step("ACT", step=step, action=action, result=result)

            # EVALUATE：判断是否完成
            done = self.evaluate(user_input, result)
            self.trace.step("EVALUATE", step=step, done=done)
            if done:
                break
        else:
            # 步数用尽仍未完成 → ABORT，防止无限循环
            log.warning("Agent[%s] 达到最大步数 %s，中止", self.name, self.max_steps)
            self.trace.step("ABORT", reason=f"达到 max_steps={self.max_steps}")

        answer = self.build_answer(user_input, result)
        self.trace.step("MESSAGE", step=step, answer=answer)
        return self.trace.trace_id, answer

    # ---------------- 子类需要实现 ----------------
    def think(self, user_input: str, last_result) -> dict:
        raise NotImplementedError

    def act(self, action: dict) -> str:
        raise NotImplementedError

    def evaluate(self, user_input: str, result: str) -> bool:
        return True

    def build_answer(self, user_input: str, result: str) -> str:
        return str(result)


class DemoAgent(AgentLoop):
    """演示 Agent：THINK 时选择"查天气 / 查知识 / 结束"三种动作之一。"""

    def think(self, user_input: str, last_result) -> dict:
        text = str(user_input).lower()
        if "天气" in text:
            return {"tool": "weather", "args": {"city": _extract_city(str(user_input))}}
        if "知识" in text and not last_result:
            return {"tool": "knowledge", "args": {"keyword": "python"}}
        return {"tool": "done", "args": {}}

    def act(self, action: dict) -> str:
        tool = action["tool"]
        if tool == "weather":
            city = action["args"]["city"]
            info = _MOCK_WEATHER.get(city, {"temp": "?", "weather": "未知", "humidity": "?"})
            return f"[天气] {city} {info['weather']} {info['temp']}℃ 湿度{info['humidity']}%"
        if tool == "knowledge":
            return "[知识] Python 是一门简洁的编程语言"
        return "[完成] 已处理完毕"

    def evaluate(self, user_input: str, result: str) -> bool:
        # 完成 / 天气结果 = 一次完成；知识结果继续走"结束"步骤（演示多步循环）
        if result.startswith(("[完成]", "[天气]")):
            return True
        return False

    def build_answer(self, user_input: str, result: str) -> str:
        return result


# 演示用：常见城市 + 模拟天气数据
_CITIES = ["深圳", "北京", "上海", "广州", "杭州"]
_MOCK_WEATHER = {
    "深圳": {"temp": "28", "weather": "晴", "humidity": "65"},
    "北京": {"temp": "22", "weather": "多云", "humidity": "45"},
    "上海": {"temp": "25", "weather": "小雨", "humidity": "80"},
    "广州": {"temp": "30", "weather": "雷阵雨", "humidity": "88"},
    "杭州": {"temp": "26", "weather": "阴", "humidity": "70"},
}


def _extract_city(text: str) -> str:
    """从问题里找城市名，找不到用默认城市。"""
    for city in _CITIES:
        if city in text:
            return city
    return "深圳"


class NeverDoneAgent(AgentLoop):
    """测试专用：永远不完成，用于验证 max_steps 兜底。"""

    def think(self, user_input, last_result) -> dict:
        return {"tool": "loop", "args": {}}

    def act(self, action: dict) -> str:
        return "还在工作中..."

    def evaluate(self, user_input: str, result: str) -> bool:
        return False  # 永不完成

    def build_answer(self, user_input: str, result: str) -> str:
        return "达到步数上限，中止（演示 max_steps 兜底）"
