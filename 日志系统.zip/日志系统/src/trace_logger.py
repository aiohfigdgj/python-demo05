# trace 日志：把 Agent 每一步执行过程结构化落盘。

from __future__ import annotations

import json
import logging
import uuid
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
TRACE_DIR = PROJECT_ROOT / "logs" / "traces"

_LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"


def setup_logging(level: int = logging.INFO, log_file: str = "agent.log") -> None:
    """初始化根日志：控制台 + 滚动文件双输出（调用一次即可）。"""
    log_dir = PROJECT_ROOT / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    root = logging.getLogger()
    if root.handlers:
        return  # 已配置过，避免重复

    from logging.handlers import RotatingFileHandler

    formatter = logging.Formatter(_LOG_FORMAT)
    console = logging.StreamHandler()
    console.setFormatter(formatter)

    file_handler = RotatingFileHandler(
        log_dir / log_file, maxBytes=2 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)

    root.setLevel(level)
    root.addHandler(console)
    root.addHandler(file_handler)


class TraceLogger:
    """一次 Agent 执行的追踪器。

    - trace_id：一次执行的唯一编号（回放凭据）
    - step(phase, **fields)：记录一步，phase ∈ OBSERVE/THINK/ACT/EVALUATE 等
    - 轨迹落盘 logs/traces/{trace_id}.jsonl（每行一个 JSON）
    """

    def __init__(self, name: str = "agent", trace_id: str | None = None):
        self.name = name
        self.trace_id = trace_id or uuid.uuid4().hex[:10]
        TRACE_DIR.mkdir(parents=True, exist_ok=True)
        self.jsonl_path = TRACE_DIR / f"{self.trace_id}.jsonl"
        self.logger = logging.getLogger(f"{name}.{self.trace_id}")

    def step(self, phase: str, **fields) -> dict:
        """记录一步执行过程，返回该步记录。"""
        record = {"trace_id": self.trace_id, "agent": self.name, "phase": phase, **fields}
        # 1) 普通日志（人读）
        self.logger.info("[TRACE] %s", json.dumps(record, ensure_ascii=False))
        # 2) 结构化轨迹（机读，供回放）
        with open(self.jsonl_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        return record

    def info(self, message: str, *args) -> None:
        self.logger.info(message, *args)

    def warning(self, message: str, *args) -> None:
        self.logger.warning(message, *args)

    def error(self, message: str, *args) -> None:
        self.logger.exception(message, *args)

    def __repr__(self) -> str:
        return f"<TraceLogger {self.name} trace_id={self.trace_id}>"
