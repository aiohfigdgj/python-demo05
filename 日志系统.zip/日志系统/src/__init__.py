"""03-日志系统：Agent Loop + 完整 trace 日志 + 回放。"""
