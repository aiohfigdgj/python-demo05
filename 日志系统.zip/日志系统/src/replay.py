# 日志回放器：读取 logs/traces/{trace_id}.jsonl，重现 Agent 执行过程。

from __future__ import annotations

import json
from pathlib import Path

from .trace_logger import TRACE_DIR

# 按语义顺序展示（同 step 内保持原序）
_PHASE_ORDER = {"OBSERVE": 0, "THINK": 1, "ACT": 2, "EVALUATE": 3, "MESSAGE": 4, "ABORT": 5}


def list_traces(trace_dir: str | Path | None = None) -> list[dict]:
    """列出全部可回放的 trace（按时间倒序）。"""
    trace_dir = Path(trace_dir or TRACE_DIR)
    if not trace_dir.exists():
        return []
    traces = []
    for jsonl in sorted(trace_dir.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True):
        traces.append({"trace_id": jsonl.stem, "file": str(jsonl), "steps": _count_steps(jsonl)})
    return traces


def _count_steps(jsonl: Path) -> int:
    try:
        with open(jsonl, encoding="utf-8") as f:
            return sum(1 for _ in f)
    except OSError:
        return 0


def load_trace(trace_id: str, trace_dir: str | Path | None = None) -> list[dict]:
    """读取某次执行的步骤记录列表（保持写入顺序）。"""
    path = Path(trace_dir or TRACE_DIR) / f"{trace_id}.jsonl"
    if not path.exists():
        return []
    steps = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                steps.append(json.loads(line))
    return steps


def replay(trace_id: str, trace_dir: str | Path | None = None) -> str:
    """把一次执行回放为可读文本（人读的流程时间线）。"""
    steps = load_trace(trace_id, trace_dir)
    if not steps:
        return f"未找到 trace_id={trace_id} 的记录，请确认 logs/traces/ 下是否存在对应文件。"

    steps = sorted(steps, key=lambda s: (_PHASE_ORDER.get(s.get("phase"), 9),))
    lines = [f"=== 回放 trace_id={trace_id}（共 {len(steps)} 步）==="]
    for s in steps:
        lines.append(_format_step(s))
    return "\n".join(lines)


def _format_step(step: dict) -> str:
    """把一条结构化记录格式化为可读的一行。"""
    phase = step.get("phase", "?")
    parts = [f"[{phase}]"]
    for key, value in step.items():
        if key in ("phase", "trace_id", "agent", "step"):
            continue
        if isinstance(value, (dict, list)):
            value = json.dumps(value, ensure_ascii=False)
        parts.append(f"{key}={value!r}")
    return " ".join(parts)
