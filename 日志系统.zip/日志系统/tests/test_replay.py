# 测试：日志回放（从 trace 日志重现 Agent 执行过程）。

from src.agent_loop import DemoAgent
from src.replay import list_traces, load_trace, replay
from src.trace_logger import TRACE_DIR


def test_replay_reconstructs_execution():
    """运行一次 Agent → 回放日志 → 能重现输入与最终答案。"""
    agent = DemoAgent("demo")
    trace_id, answer = agent.run("深圳今天天气怎么样？")

    text = replay(trace_id, TRACE_DIR)
    assert f"trace_id={trace_id}" in text
    assert "[OBSERVE]" in text and "深圳今天天气怎么样" in text
    assert "[THINK]" in text and "weather" in text
    assert "[ACT]" in text
    assert "[EVALUATE]" in text
    assert "[MESSAGE]" in text and "晴" in text


def test_load_trace_ordered_steps():
    """写入顺序即执行顺序：OBSERVE 在最前。"""
    agent = DemoAgent("demo")
    trace_id, _ = agent.run("深圳天气")

    steps = load_trace(trace_id, TRACE_DIR)
    assert steps, "trace 文件不应为空"
    assert steps[0]["phase"] == "OBSERVE"
    assert all(s["agent"] == "demo" for s in steps)


def test_list_traces_contains_new():
    agent = DemoAgent("demo")
    trace_id, _ = agent.run("北京天气")

    traces = list_traces(TRACE_DIR)
    ids = [t["trace_id"] for t in traces]
    assert trace_id in ids
    found = [t for t in traces if t["trace_id"] == trace_id][0]
    assert found["steps"] >= 5


def test_replay_unknown_trace():
    text = replay("不存在之id", TRACE_DIR)
    assert "未找到" in text


def test_replay_empty_dir(tmp_path):
    assert list_traces(tmp_path) == []
