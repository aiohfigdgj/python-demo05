"""测试：Agent Loop 的 trace 日志（阶段完整 / max_steps 兜底）。"""
from src.agent_loop import DemoAgent, NeverDoneAgent
from src.trace_logger import TRACE_DIR, setup_logging


def setup_module():
    setup_logging()


def test_full_trace_phases():
    """一次正常执行应产生 OBSERVE/THINK/ACT/EVALUATE/MESSAGE 完整轨迹。"""
    agent = DemoAgent("demo")
    trace_id, answer = agent.run("深圳今天天气怎么样？")

    from src.replay import load_trace

    steps = load_trace(trace_id, TRACE_DIR)
    phases = [s["phase"] for s in steps]
    assert phases[0] == "OBSERVE"
    for expected in ("OBSERVE", "THINK", "ACT", "EVALUATE", "MESSAGE"):
        assert expected in phases
    assert answer == "[天气] 深圳 晴 28℃ 湿度65%"


def test_multi_step_loop():
    """多步执行：知识问题先查知识、再结束，共 2 轮，每轮都有 trace。"""
    agent = DemoAgent("demo")
    trace_id, answer = agent.run("讲讲python知识")

    from src.replay import load_trace

    steps = load_trace(trace_id, TRACE_DIR)
    thinks = [s for s in steps if s["phase"] == "THINK"]
    acts = [s for s in steps if s["phase"] == "ACT"]
    assert len(thinks) == 2  # 第一轮知识 + 第二轮结束
    assert "[知识]" in acts[0]["result"]  # 第一轮拿到知识结果
    assert answer.startswith("[完成]")    # 最终回答


def test_trace_id_unique():
    """每次执行 trace_id 不同，可区分。"""
    agent = DemoAgent("demo")
    id1, _ = agent.run("天气")
    id2, _ = agent.run("天气")
    assert id1 != id2


def test_max_steps_abort():
    """步数用尽应 ABORT 并停止，不无限循环。"""
    agent = NeverDoneAgent("never", max_steps=2)
    trace_id, answer = agent.run("继续")
    assert "中止" in answer

    from src.replay import load_trace

    steps = load_trace(trace_id, TRACE_DIR)
    phases = [s["phase"] for s in steps]
    assert "ABORT" in phases
    assert phases.count("ACT") == 2  # 只执行了 2 步就中止


def test_trace_jsonl_file_created():
    """执行后 logs/traces/ 下应有对应 jsonl 文件。"""
    agent = DemoAgent("demo")
    trace_id, _ = agent.run("测试文件生成")
    path = TRACE_DIR / f"{trace_id}.jsonl"
    assert path.exists()
    assert path.stat().st_size > 0
