# 任务03 · 日志系统

> Agent Loop 加完整 trace 日志，能从日志回放执行过程。

## 核心设计

```
Agent Loop:  OBSERVE → THINK → ACT → EVALUATE（未完成循环，max_steps 兜底 → ABORT）
                │
                └── 每一步写入 logs/traces/{trace_id}.jsonl（结构化轨迹）
                     + logs/agent.log（人类可读的普通日志）
```

- **trace_id**：一次执行一个唯一编号，回放凭据
- **轨迹文件**：每行一个 JSON，机器可读，`replay.py` 按时间线重建执行过程
- **日志 = Agent 的黑匣子**：出了错误决策，回放"思考过程"即可定位问题

## 目录结构

```
03-日志系统/
├── src/
│   ├── agent_loop.py     # Agent Loop（OBSERVE/THINK/ACT/EVALUATE/ABORT）
│   ├── trace_logger.py   # trace 日志（普通日志 + jsonl 结构化轨迹）
│   └── replay.py         # 回放器（list_traces / load_trace / replay）
├── tests/
│   ├── test_agent_logging.py  # 阶段完整、多步循环、max_steps 兜底
│   └── test_replay.py         # 回放重建执行过程
├── pytest.ini
└── requirements.txt
```

## 演示

```bash
# ★ 交互模式（推荐）：连续输入问题，Agent 回答并自动回放
python run.py

# 单次模式
python run.py "北京天气"
```

等价写法（包模式）：
```bash
python -c "
from src.agent_loop import DemoAgent
from src.trace_logger import setup_logging
setup_logging()
trace_id, answer = DemoAgent('demo').run('深圳今天天气怎么样？')
print('回答:', answer)
print('回放:')
from src.replay import replay
print(replay(trace_id))
"
```

回放输出示例：

```
=== 回放 trace_id=xxxxxxxxxx（共 5 步）===
[OBSERVE] input='深圳今天天气怎么样？'
[THINK]   plan='{"tool": "weather", "args": {"city": "深圳"}}'
[ACT]     result='[天气] 深圳 晴 28℃ 湿度65%'
[EVALUATE] done=True
[MESSAGE] answer='[天气] 深圳 晴 28℃ 湿度65%'
```

