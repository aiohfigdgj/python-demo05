"""项目启动器：日志系统交互演示。

用法：
    python run.py                  # ★ 交互模式：输入问题，Agent 回答并回放 trace
    python run.py "北京天气"       # 单次运行并回放
"""
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.agent_loop import DemoAgent  # noqa: E402
from src.replay import replay  # noqa: E402
from src.trace_logger import setup_logging  # noqa: E402

EXIT_WORDS = ("退出", "exit", "quit", "q")


def run_once(question: str) -> None:
    """跑一次 Agent，打印回答 + 回放 trace。"""
    trace_id, answer = DemoAgent("demo").run(question)
    print("回答:", answer)
    print()
    print(replay(trace_id))
    print("-" * 40)


if __name__ == "__main__":
    setup_logging()

    # 单次模式：run.py "问题"
    if len(sys.argv) > 1:
        run_once(sys.argv[1])
        sys.exit(0)

    # 交互模式：连续对话，每轮都是"执行 + 回放"
    print("=" * 40)
    print("  日志系统 · 交互演示（Agent + trace 回放）")
    print("=" * 40)
    print("试试：深圳天气 / 北京天气 / 讲讲python知识")
    print("输入「退出」结束")
    print("-" * 40)

    while True:
        try:
            question = input("> ").strip()
        except EOFError:  # Ctrl+D / 管道输入结束
            break
        if not question:
            continue
        if question.lower() in EXIT_WORDS:
            print("拜拜~")
            break
        run_once(question)